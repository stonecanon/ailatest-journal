(function (root) {
  'use strict';

  const ns = root.AILatestExt = root.AILatestExt || {};

  // 三主题色板（与 journal.ailatest.org 的 css/app.css 对齐）。
  // site = 网站默认（琥珀分区 + 深蓝索引）；light = 淡雅浅底深字；dark = 高饱和深色。
  // 每组一个 CSS 变量，custom 颜色（cas/jcr/if/idx）通过 :host 覆盖对应变量。
  const THEME_VARS = {
    site: {
      '--c-cas': '#735a3e', '--c-jcr': '#735a3e', '--c-if': '#735a3e',
      '--c-idx': '#1f3a5f', '--c-ccf': '#72728d', '--c-biz': '#724a58',
      '--c-tier': '#72849b', '--c-cssci': '#6a3a8b', '--c-cssciext': '#8a5aa6',
      '--c-pku': '#a33a2a', '--c-cscd': '#4f6f7c', '--c-zju': '#1f5f5a',
      '--c-nsfc': '#0f766e', '--c-scd': '#5a6b3a', '--c-ami': '#6a5a3a',
      '--c-warn': '#b23a3a', '--c-warnsoft': '#6f665d', '--c-onhold': '#d94a1e',
      '--c-free': '#1d6f42', '--c-link': '#526b86',
      '--txt': '#fff', '--bd': 'transparent',
    },
    light: {
      '--c-cas': '#f1ece3', '--c-jcr': '#e7f2ef', '--c-if': '#f4f1ec',
      '--c-idx': '#e9eef5', '--c-ccf': '#eceaf4', '--c-biz': '#f4eaef',
      '--c-tier': '#eaeef5', '--c-cssci': '#f1eaf6', '--c-cssciext': '#f1eaf6',
      '--c-pku': '#f8eae7', '--c-cscd': '#e9f0f2', '--c-zju': '#e6f1ef',
      '--c-nsfc': '#e6f2f0', '--c-scd': '#eef1e6', '--c-ami': '#f1ede4',
      '--c-warn': '#fbeaea', '--c-warnsoft': '#f0eeeb', '--c-onhold': '#fdebe2',
      '--c-free': '#e7f3ec', '--c-link': '#eaeef5',
      '--txt': '#3a342c', '--bd': 'rgba(0,0,0,.10)',
    },
    dark: {
      '--c-cas': '#c0392b', '--c-jcr': '#16a085', '--c-if': '#2b2824',
      '--c-idx': '#2c5d8f', '--c-ccf': '#5b5b8a', '--c-biz': '#8a4a66',
      '--c-tier': '#4a6285', '--c-cssci': '#7a3a9b', '--c-cssciext': '#9a5ab6',
      '--c-pku': '#c0392b', '--c-cscd': '#3a6f7c', '--c-zju': '#1f7f6a',
      '--c-nsfc': '#0f8a7e', '--c-scd': '#6a7b3a', '--c-ami': '#8a6a3a',
      '--c-warn': '#d0392b', '--c-warnsoft': '#7f766d', '--c-onhold': '#e9531e',
      '--c-free': '#2d8a4e', '--c-link': '#3a6296',
      '--txt': '#fff', '--bd': 'transparent',
    },
  };

  const STYLE = `
    :host { all: initial; }
    .wrap {
      display: inline-flex; align-items: center; flex-wrap: wrap;
      gap: 4px 5px; margin: 4px 0; max-width: 100%;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", Arial, sans-serif;
      line-height: 1.45; vertical-align: middle;
    }
    .pill {
      display: inline-flex; align-items: center; max-width: 260px;
      padding: 1px 6px; border-radius: 2px;
      color: var(--txt); border: 1px solid var(--bd);
      font-size: 10.5px; font-weight: 700; letter-spacing: .04em;
      line-height: 1.5; white-space: nowrap; overflow: hidden;
      text-overflow: ellipsis; box-sizing: border-box;
    }
    .cas{background:var(--c-cas)} .jcr{background:var(--c-jcr)} .if{background:var(--c-if)}
    .idx{background:var(--c-idx)} .ccf{background:var(--c-ccf)} .biz{background:var(--c-biz)}
    .tier{background:var(--c-tier)} .cssci{background:var(--c-cssci)} .cssci-ext{background:var(--c-cssciext)}
    .pku{background:var(--c-pku)} .cscd{background:var(--c-cscd)} .zju{background:var(--c-zju)}
    .nsfc{background:var(--c-nsfc)} .scd{background:var(--c-scd)} .ami{background:var(--c-ami)}
    .warning{background:var(--c-warn)} .warnsoft{background:var(--c-warnsoft)} .onhold{background:var(--c-onhold)}
    .free{background:var(--c-free)}
    a.pill { background: var(--c-link); text-decoration: none; cursor: pointer; }
    a.pill:hover { filter: brightness(1.06); }
    /* 类别分隔线：收录 | 分级 | 免费开放 | 预警 之间 */
    .sep { width: 1px; align-self: stretch; min-height: 13px; margin: 0 2px;
           background: currentColor; opacity: .22; }
  `;

  function add(out, enabled, text, className, title) {
    if (!enabled || text === '' || text == null) return;
    out.push({ text: String(text), className: 'pill ' + (className || ''), title: title || '' });
  }

  function formatIf(value) {
    const n = Number(value);
    return Number.isFinite(n) ? n.toFixed(1) : '';
  }

  // 对象/数组字段取值（与 css/app.css 的标签口径一致）
  const val = (x) => (x && typeof x === 'object' ? (x.rating || x.tier || '') : (x || ''));
  function bestVhb(vhb) {
    const order = { 'A+': 5, A: 4, B: 3, C: 2, D: 1 };
    const arr = Array.isArray(vhb) ? vhb : [];
    let best = null;
    for (const v of arr) if (!best || (order[v.rating] || 0) > (order[best.rating] || 0)) best = v;
    return best;
  }

  // 四大类，按 收录 → 分级 → 免费开放 → 预警 顺序展示，类间以分隔线区隔。
  // 收录=数据库/目录收录事实；分级=质量分区/评级；免费开放=OA/免 APC；预警=风险信号。
  function makeBadges(journal, settings) {
    const j = journal || {};
    const s = settings || {};

    // ── 收录 ──（国际索引 + 国内来源目录：被收录的事实，无质量分级）
    const indexing = [];
    if (Array.isArray(j.indices)) for (const idx of j.indices) add(indexing, s.showIndex, idx, 'idx', '收录索引');
    add(indexing, s.showIndex, j.scopus ? 'Scopus' : '', 'idx', j.scopus_discontinued ? 'Scopus（已停止收录）' : 'Scopus 收录');
    add(indexing, s.showCnIndex, j.pku ? '北大核心' : '', 'pku', '北大中文核心期刊要目总览');
    add(indexing, s.showCnIndex, j.cssci === 'core' ? 'CSSCI' : '', 'cssci', 'CSSCI 来源期刊');
    add(indexing, s.showCnIndex, j.cssci === 'ext' ? 'CSSCI扩展' : '', 'cssci-ext', 'CSSCI 扩展版来源期刊');
    add(indexing, s.showCnIndex, j.cscd ? `CSCD${typeof j.cscd === 'string' ? ' ' + j.cscd : ''}` : '', 'cscd', '中国科学引文数据库');

    // ── 分级 ──（国际分区/评级 + 国内分级目录：有等级高低）
    const rating = [];
    add(rating, s.showCas, j.cas_zone ? `中科院${j.cas_zone}区${j.cas_top ? ' TOP' : ''}` : '', 'cas', '中科院文献情报中心分区表 2025');
    if (j.cas_xr && j.cas_xr.zone) add(rating, s.showCas, `新锐${j.cas_xr.zone}区${j.cas_xr.top ? ' TOP' : ''}`, 'cas', '中科院新锐版 2026');
    if (j.cas_mega) add(rating, s.showCas, 'MEGA', 'cas', '中科院开放获取大刊');
    add(rating, s.showJcr, j.if_quartile, 'jcr', 'JCR 分区 Quartile');
    add(rating, s.showIf, j.if_2024 != null ? `IF ${formatIf(j.if_2024)}` : '', 'if', 'JCR 影响因子 2024');
    add(rating, s.showCcf, j.ccf ? `CCF ${j.ccf}` : '', 'ccf', 'CCF 推荐目录 2026');
    add(rating, s.showBusiness, val(j.abdc) ? `ABDC ${val(j.abdc)}` : '', 'biz', 'ABDC 期刊质量目录 2025');
    add(rating, s.showBusiness, val(j.abs) ? `ABS ${val(j.abs)}` : '', 'biz', 'Chartered ABS AJG 2024');
    add(rating, s.showBusiness, j.fms && j.fms.tier ? `FMS ${j.fms.tier}` : '', 'biz', 'FMS 管理科学高质量期刊');
    const vhb = bestVhb(j.vhb);
    add(rating, s.showBusiness, vhb ? `VHB ${vhb.rating}` : '', 'biz', 'VHB-JOURQUAL 2024 德语区商科/管理期刊分级；B = 良好/认可级');
    const cnrs = Array.isArray(j.cnrs) && j.cnrs[0];
    add(rating, s.showBusiness, cnrs && cnrs.category ? `CNRS ${cnrs.category}级` : '', 'biz', '法国 CNRS Section 37 经济/管理期刊分级，2020 历史参考；1 = 高等级');
    if (Array.isArray(j.cnkx)) for (const c of j.cnkx) {
      add(rating, s.showCnTier, c.domain ? `科协${c.tier} ${c.domain}` : `科协${c.tier}`, 'tier', '中国科协高质量科技期刊分级目录 2025');
    }
    add(rating, s.showCnTier, j.ccft ? `CCF-T ${j.ccft}` : '', 'tier', 'CCF 计算领域高质量科技期刊 T 级 2025');
    add(rating, s.showCnTier, j.scd ? `SCD${j.scd.category ? ' ' + j.scd.category : ''}` : '', 'scd', 'SCD 分级');
    add(rating, s.showCnTier, j.ami && j.ami.tier ? `AMI ${j.ami.tier}` : '', 'ami', 'AMI 综合评价（社科）');
    add(rating, s.showCnTier, j.zju ? `浙大 ${j.zju}` : '', 'zju', '浙江大学期刊分级 2024');
    add(rating, s.showCnTier, j.nsfc_mgmt ? `NSFC ${j.nsfc_mgmt}` : '', 'nsfc', '国家自然科学基金委管理科学部目录');

    // ── 免费开放 ──
    const oa = [];
    add(oa, s.showFree, j.free ? '免费发表' : '', 'free', '免 APC 发表');
    add(oa, s.showFree, /^no$/i.test(String(j.doaj_apc || '')) ? 'DOAJ 免APC' : '', 'free', 'DOAJ 收录且免 APC');

    // ── 预警 / 风险 ──
    const warn = [];
    add(warn, s.showWarnings, j.warning ? '预警' : '', 'warning', '国际期刊预警名单');
    add(warn, s.showWarnings, j.citic_warning ? '中信所预警' : '', 'warning', '中科院文献情报中心预警');
    add(warn, s.showWarnings, j.on_hold ? 'On Hold' : '', 'onhold', 'WoS 暂停收录');
    add(warn, s.showWarnings, j.under_review ? 'Under Review' : '', 'onhold', '新锐版审查中');
    add(warn, s.showWarnings, j.scopus_discontinued ? 'Scopus 停收' : '', 'warnsoft', 'Scopus 已停止收录');
    if (j.retraction && (j.retraction.total || j.retraction.retractions_total)) {
      const total = j.retraction.total || j.retraction.retractions_total;
      const rate = j.retraction.rate_per_1000_10y != null ? `；近10年每千篇约 ${j.retraction.rate_per_1000_10y}/1000` : '';
      add(warn, s.showWarnings, `撤稿 ${total}`, 'warnsoft', `Retraction Watch 撤稿记录（风险提示，不作排名）${rate}`);
    }

    // 拼接：非空类别之间插入分隔线
    const out = [];
    for (const group of [indexing, rating, oa, warn]) {
      if (!group.length) continue;
      if (out.length) out.push({ sep: true });
      out.push(...group);
    }
    return out;
  }

  function applyTheme(host, settings) {
    const theme = ['site', 'light', 'dark'].includes(settings && settings.theme) ? settings.theme : 'site';
    const vars = { ...THEME_VARS[theme] };
    // 自定义颜色覆盖（仅 4 个主组；空值/非法忽略，回落主题色）
    const colors = (settings && settings.colors) || {};
    const map = { cas: '--c-cas', jcr: '--c-jcr', if: '--c-if', idx: '--c-idx' };
    for (const k in map) {
      if (/^#[0-9a-fA-F]{3,8}$/.test(colors[k] || '')) {
        vars[map[k]] = colors[k];
        if (theme === 'light') vars['--txt'] = '#fff'; // 自定义实色块用白字更稳
      }
    }
    return Object.entries(vars).map(([k, v]) => `${k}:${v}`).join(';');
  }

  function renderBadges(journal, settings) {
    const host = document.createElement('span');
    host.className = 'ailatest-journal-badges';
    host.dataset.ailatestBadge = '1';

    const shadow = host.attachShadow({ mode: 'open' });
    const style = document.createElement('style');
    style.textContent = STYLE;
    const wrap = document.createElement('span');
    wrap.className = 'wrap';
    wrap.setAttribute('style', applyTheme(host, settings));

    makeBadges(journal, settings).forEach((badge) => {
      if (badge.sep) {
        const sep = document.createElement('span');
        sep.className = 'sep';
        wrap.appendChild(sep);
        return;
      }
      const el = document.createElement('span');
      el.className = badge.className;
      el.textContent = badge.text;
      if (badge.title) el.title = badge.title;
      wrap.appendChild(el);
    });

    if (journal && journal.slug) {
      const link = document.createElement('a');
      link.className = 'pill';
      link.href = `https://journal.ailatest.org/journal/${encodeURIComponent(journal.slug)}`;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.textContent = 'AILatest';
      link.title = '查看期刊详情 — AILatest Journal';
      wrap.appendChild(link);
    }

    shadow.append(style, wrap);
    return host;
  }

  ns.badges = { renderBadges, makeBadges };
})(globalThis);
