# AILatest Journal 浏览器插件（MV3）

在 Google Scholar、PubMed、知网页面注入期刊评级徽章：影响因子、中科院分区/新锐、JCR Quartile、
收录索引、CCF/ABDC/ABS/FMS/VHB/CNRS、国内目录（核心/CSSCI/科协/CSCD/浙大…）、预警与撤稿。
商业规则唯一来源：[docs/entitlements.spec.json](../docs/entitlements.spec.json)。

## 架构（v0.2.0，服务端数据 + 验证）

- **数据走服务端 `/api/ext/lookup`，不再本地打包**：徽章数据是站点核心资产，本地打包会被整库提取。
  现按刊名/ISSN 向服务端批量查询（≤100 条/次），返回完整富数据；客户端 7 天缓存命中不再请求。
- **服务端验证防抓取**（[worker/src/ext-lookup.js](../worker/src/ext-lookup.js)）：按身份限每日查询条数
  （匿名按 IP 800/日，登录用户 10000/日，owner 不限），超额返回 429 引导登录。挡住"一下子被整库拖走"。
- **adapter 架构**：[src/adapters/](src/adapters/) 每站点一个适配器（googleScholar / pubmed / cnki），
  [src/content.js](src/content.js) 统一扫描 + MutationObserver 跟进动态加载。
- **Shadow DOM 徽章**（[src/badges.js](src/badges.js)）：`:host { all: initial }` 隔离页面 CSS；
  **所有标签全部渲染，不截断**（indices / 科协多学科全列）；三主题 site/light/dark + 4 主组自定义色。
- **登录**：popup 内邮箱验证码直登；GitHub/Google 走网站 signup.html?ext=1，[src/bridge.js](src/bridge.js)
  把网站登录态同步进 chrome.storage；登录后查询额度更高。

## 设置（popup）

- 主题：网站默认 / 淡雅 / 深色
- 9 类徽章显示开关
- 4 主组（分区 / JCR / IF / 索引）自定义颜色，留默认则跟随主题
- 存 chrome.storage.sync 的 `ajSettings`，改完刷新页面生效

## 本地开发

1. `chrome://extensions` → 开发者模式 → 加载已解压的扩展程序 → 选 `extension/`
2. 打开 scholar.google.com / pubmed.ncbi.nlm.nih.gov / cnki.net 搜索，结果行出现评级徽章
3. 数据接口与验证在 worker：`cd worker && npx wrangler dev`（lookup 数据从 CDN 实时拉取）

## 数据构建

`python3 scripts/build_ext_lookup.py` → `data/ext_lookup.json.gz`（服务端 `/ext/lookup` 读取，随网站部署上线）。

## 加站点适配器

1. 新增 `src/adapters/<site>.js`，push 进 `AILatestExt.adapters`：
   `{ id, match: (host)=>/.../.test(host), findEntries: ()=>[{anchorEl, issn?, journalName}], insert: (anchorEl, node)=>... }`
2. 在 manifest.json 的 content_scripts 加入文件与 match。
3. 页面暴露 ISSN 时优先用 ISSN；否则仅在文本明确是刊名时回退刊名。

## 待办

- ⬜ 收藏星标注入 + 同步 fav_lists
- ⬜ entitlements 快照（/api/me/entitlements 已上线）在 popup 渲染试用倒计时
- ⬜ PubMed 搜索结果用 ISO 缩写匹配（详情页全名已可用；缩写键待服务端补）
- ⬜ 更多站点：Web of Science、Scopus、出版商文章页
