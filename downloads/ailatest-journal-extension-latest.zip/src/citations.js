(function (root) {
  'use strict';

  const ns = root.AILatestExt = root.AILatestExt || {};

  function clean(value) {
    return String(value || '').replace(/\s+/g, ' ').trim();
  }

  function escBib(value) {
    return clean(value).replace(/[{}\\]/g, '\\$&');
  }

  function meta(name) {
    const values = Array.from(document.querySelectorAll(`meta[name="${name}"], meta[property="${name}"]`))
      .map((el) => clean(el.getAttribute('content')))
      .filter(Boolean);
    return values;
  }

  function first(...values) {
    for (const value of values.flat()) {
      const v = clean(value);
      if (v) return v;
    }
    return '';
  }

  function yearOf(data) {
    const date = first(data.date, data.year);
    const m = date.match(/\b(19|20)\d{2}\b/);
    return m ? m[0] : '';
  }

  function authorsText(authors, joiner = ', ') {
    return (authors || []).map(clean).filter(Boolean).join(joiner);
  }

  function citationKey(data) {
    const firstAuthor = clean((data.authors || [])[0] || 'article').split(/\s+/).pop() || 'article';
    return `${firstAuthor}${yearOf(data) || 'nd'}`.replace(/[^a-z0-9_:-]/gi, '');
  }

  function fromDocument(extra = {}) {
    const doi = first(extra.doi, meta('citation_doi'), meta('dc.Identifier')).replace(/^doi:\s*/i, '');
    return {
      title: first(extra.title, meta('citation_title'), meta('dc.Title'), meta('og:title'), document.title),
      journal: first(extra.journal, meta('citation_journal_title'), meta('dc.Source')),
      authors: (extra.authors && extra.authors.length ? extra.authors : meta('citation_author')).map(clean).filter(Boolean),
      abstract: first(extra.abstract, meta('citation_abstract'), meta('dc.Description'), meta('description')),
      year: first(extra.year, meta('citation_publication_date'), meta('citation_online_date'), meta('dc.Date')),
      date: first(extra.date, meta('citation_publication_date'), meta('citation_online_date'), meta('dc.Date')),
      volume: first(extra.volume, meta('citation_volume')),
      issue: first(extra.issue, meta('citation_issue')),
      firstPage: first(extra.firstPage, meta('citation_firstpage')),
      lastPage: first(extra.lastPage, meta('citation_lastpage')),
      doi,
      issn: first(extra.issn, meta('citation_issn'), meta('citation_eissn')),
      url: first(extra.url, meta('citation_public_url'), meta('og:url'), location.href),
      pdfUrl: first(extra.pdfUrl, meta('citation_pdf_url')),
    };
  }

  function ris(data) {
    const lines = ['TY  - JOUR'];
    (data.authors || []).forEach((a) => lines.push(`AU  - ${a}`));
    if (data.title) lines.push(`TI  - ${data.title}`);
    if (data.journal) lines.push(`JO  - ${data.journal}`);
    if (yearOf(data)) lines.push(`PY  - ${yearOf(data)}`);
    if (data.volume) lines.push(`VL  - ${data.volume}`);
    if (data.issue) lines.push(`IS  - ${data.issue}`);
    if (data.firstPage) lines.push(`SP  - ${data.firstPage}`);
    if (data.lastPage) lines.push(`EP  - ${data.lastPage}`);
    if (data.doi) lines.push(`DO  - ${data.doi}`);
    if (data.url) lines.push(`UR  - ${data.url}`);
    if (data.pdfUrl) lines.push(`L1  - ${data.pdfUrl}`);
    lines.push('ER  - ');
    return lines.join('\r\n') + '\r\n';
  }

  function enw(data) {
    const lines = ['%0 Journal Article'];
    (data.authors || []).forEach((a) => lines.push(`%A ${a}`));
    if (data.title) lines.push(`%T ${data.title}`);
    if (data.journal) lines.push(`%J ${data.journal}`);
    if (yearOf(data)) lines.push(`%D ${yearOf(data)}`);
    if (data.volume) lines.push(`%V ${data.volume}`);
    if (data.issue) lines.push(`%N ${data.issue}`);
    if (data.firstPage || data.lastPage) lines.push(`%P ${data.firstPage || ''}-${data.lastPage || ''}`.replace(/-$/, ''));
    if (data.doi) lines.push(`%R ${data.doi}`);
    if (data.url) lines.push(`%U ${data.url}`);
    if (data.pdfUrl) lines.push(`%> ${data.pdfUrl}`);
    return lines.join('\r\n') + '\r\n';
  }

  function bibtex(data) {
    const pages = data.firstPage || data.lastPage ? `${data.firstPage || ''}${data.lastPage ? '--' + data.lastPage : ''}` : '';
    const fields = [
      ['title', data.title],
      ['author', (data.authors || []).join(' and ')],
      ['journal', data.journal],
      ['year', yearOf(data)],
      ['volume', data.volume],
      ['number', data.issue],
      ['pages', pages],
      ['doi', data.doi],
      ['url', data.url],
    ].filter(([, v]) => clean(v));
    return `@article{${citationKey(data)},\n${fields.map(([k, v]) => `  ${k} = {${escBib(v)}}`).join(',\n')}\n}\n`;
  }

  function apa(data) {
    const authors = authorsText(data.authors) || '';
    return `${authors}${authors ? ' ' : ''}(${yearOf(data) || 'n.d.'}). ${data.title || ''}. ${data.journal || ''}${data.volume ? ', ' + data.volume : ''}${data.issue ? '(' + data.issue + ')' : ''}${data.firstPage ? ', ' + data.firstPage + (data.lastPage ? '-' + data.lastPage : '') : ''}.${data.doi ? ' https://doi.org/' + data.doi : ''}`.replace(/\s+/g, ' ').trim();
  }

  function numbered(data) {
    const pages = data.firstPage ? `:${data.firstPage}${data.lastPage ? '-' + data.lastPage : ''}` : '';
    return `${authorsText(data.authors)}. ${data.title}. ${data.journal}. ${yearOf(data)}${data.volume ? ';' + data.volume : ''}${data.issue ? '(' + data.issue + ')' : ''}${pages}.${data.doi ? ' doi:' + data.doi : ''}`.replace(/\s+/g, ' ').trim();
  }

  function gbt(data) {
    return `${authorsText(data.authors)}. ${data.title}[J]. ${data.journal}, ${yearOf(data)}${data.volume ? ', ' + data.volume : ''}${data.issue ? '(' + data.issue + ')' : ''}${data.firstPage ? ': ' + data.firstPage + (data.lastPage ? '-' + data.lastPage : '') : ''}.`.replace(/\s+/g, ' ').trim();
  }

  function downloadBlob(filename, blob) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 3000);
  }

  function download(filename, text, type = 'text/plain;charset=utf-8') {
    downloadBlob(filename, new Blob([text], { type }));
  }

  function markdownValue(value) {
    return clean(value).replace(/"/g, '\\"');
  }

  function markdownList(value) {
    return (value || []).map(clean).filter(Boolean).join('; ');
  }

  function citationMarkdown(data) {
    const title = clean(data.title) || 'Untitled article';
    const authors = markdownList(data.authors);
    const year = yearOf(data);
    const reference = apa(data) || gbt(data) || title;
    const lines = [
      '---',
      `title: "${markdownValue(title)}"`,
      authors ? `authors: "${markdownValue(authors)}"` : '',
      data.journal ? `journal: "${markdownValue(data.journal)}"` : '',
      year ? `year: "${markdownValue(year)}"` : '',
      data.doi ? `doi: "${markdownValue(data.doi)}"` : '',
      `saved_at: "${new Date().toISOString()}"`,
      'source: "AILatest Journal Extension"',
      '---',
      '',
      `# ${title}`,
      '',
      '## Authors',
      '',
      authors || '作者待补充',
      '',
      '## Abstract',
      '',
      clean(data.abstract) || '摘要待补充',
      '',
      '## Reference',
      '',
      reference,
      '',
    ].filter((line) => line !== '').join('\n');
    return `${lines}\n`;
  }

  function storageGet(key) {
    return new Promise((resolve) => {
      try {
        if (root.chrome && chrome.storage && chrome.storage.local) {
          chrome.storage.local.get(key, (res) => resolve(res && res[key]));
          return;
        }
      } catch (_) {}
      try {
        resolve(JSON.parse(localStorage.getItem(key) || 'null'));
      } catch (_) {
        resolve(null);
      }
    });
  }

  function storageSet(key, value) {
    return new Promise((resolve) => {
      try {
        if (root.chrome && chrome.storage && chrome.storage.local) {
          chrome.storage.local.set({ [key]: value }, resolve);
          return;
        }
      } catch (_) {}
      try { localStorage.setItem(key, JSON.stringify(value)); } catch (_) {}
      resolve();
    });
  }

  async function saveCitation(data, format) {
    const key = 'ajCitationLibrary';
    const list = await storageGet(key);
    const library = Array.isArray(list) ? list : [];
    const id = `${citationKey(data)}-${Date.now().toString(36)}`;
    const record = {
      id,
      format: format || 'md',
      title: clean(data.title),
      authors: (data.authors || []).map(clean).filter(Boolean),
      abstract: clean(data.abstract),
      reference: apa(data) || gbt(data) || clean(data.title),
      journal: clean(data.journal),
      year: yearOf(data),
      doi: clean(data.doi),
      url: clean(data.url),
      pdfUrl: clean(data.pdfUrl),
      savedAt: new Date().toISOString(),
      source: location.href,
    };
    library.unshift(record);
    await storageSet(key, library.slice(0, 500));
    return record;
  }

  function wrapCanvasText(ctx, text, x, y, maxWidth, lineHeight, maxLines = 12) {
    const chars = Array.from(clean(text));
    if (!chars.length) return y;
    let line = '';
    let lines = 0;
    for (const ch of chars) {
      const next = line + ch;
      if (line && ctx.measureText(next).width > maxWidth) {
        ctx.fillText(line, x, y);
        y += lineHeight;
        line = ch;
        lines += 1;
        if (lines >= maxLines) return y;
      } else {
        line = next;
      }
    }
    if (line && lines < maxLines) {
      ctx.fillText(line, x, y);
      y += lineHeight;
    }
    return y;
  }

  function bytesFromString(text) {
    const out = new Uint8Array(text.length);
    for (let i = 0; i < text.length; i += 1) out[i] = text.charCodeAt(i) & 0xff;
    return out;
  }

  function pdfWithJpeg(jpeg, imageWidth, imageHeight) {
    const pageW = 595.28;
    const pageH = 841.89;
    const margin = 32;
    const drawW = pageW - margin * 2;
    const drawH = Math.min(pageH - margin * 2, drawW * imageHeight / imageWidth);
    const drawX = margin;
    const drawY = pageH - margin - drawH;
    const content = `q\n${drawW.toFixed(2)} 0 0 ${drawH.toFixed(2)} ${drawX.toFixed(2)} ${drawY.toFixed(2)} cm\n/Im0 Do\nQ\n`;
    const chunks = [];
    const offsets = [0];
    let pos = 0;
    const push = (chunk) => {
      const bytes = typeof chunk === 'string' ? bytesFromString(chunk) : chunk;
      chunks.push(bytes);
      pos += bytes.length;
    };
    const obj = (id, body) => {
      offsets[id] = pos;
      push(`${id} 0 obj\n${body}\nendobj\n`);
    };
    push('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n');
    obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
    obj(2, '<< /Type /Pages /Kids [3 0 R] /Count 1 >>');
    obj(3, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageW} ${pageH}] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>`);
    offsets[4] = pos;
    push(`4 0 obj\n<< /Type /XObject /Subtype /Image /Width ${imageWidth} /Height ${imageHeight} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpeg.length} >>\nstream\n`);
    push(jpeg);
    push('\nendstream\nendobj\n');
    obj(5, `<< /Length ${content.length} >>\nstream\n${content}endstream`);
    const xref = pos;
    push(`xref\n0 6\n0000000000 65535 f \n`);
    for (let i = 1; i <= 5; i += 1) push(`${String(offsets[i]).padStart(10, '0')} 00000 n \n`);
    push(`trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`);
    return new Blob(chunks, { type: 'application/pdf' });
  }

  async function citationPdf(data) {
    const canvas = document.createElement('canvas');
    canvas.width = 1200;
    canvas.height = 1600;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#fffdf8';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#6b3f18';
    ctx.font = '700 34px -apple-system,BlinkMacSystemFont,Segoe UI,Arial,sans-serif';
    ctx.fillText('AILatest Journal Citation Card', 80, 96);
    ctx.fillStyle = '#1f2933';
    ctx.font = '800 46px -apple-system,BlinkMacSystemFont,Segoe UI,Arial,sans-serif';
    let y = wrapCanvasText(ctx, data.title || 'Untitled article', 80, 190, 1040, 62, 7) + 22;
    ctx.font = '500 25px -apple-system,BlinkMacSystemFont,Segoe UI,Arial,sans-serif';
    ctx.fillStyle = '#46546a';
    const rows = [
      ['Authors', markdownList(data.authors)],
      ['Abstract', clean(data.abstract) || '摘要待补充'],
    ].filter(([, value]) => clean(value));
    for (const [label, value] of rows) {
      ctx.fillStyle = '#8a5a2b';
      ctx.font = '800 24px -apple-system,BlinkMacSystemFont,Segoe UI,Arial,sans-serif';
      ctx.fillText(`${label}:`, 80, y);
      ctx.fillStyle = '#2f3a45';
      ctx.font = '500 24px -apple-system,BlinkMacSystemFont,Segoe UI,Arial,sans-serif';
      y = wrapCanvasText(ctx, value, 245, y, 875, 34, label === 'Abstract' ? 10 : 4) + 10;
    }
    ctx.fillStyle = '#8a5a2b';
    ctx.font = '800 28px -apple-system,BlinkMacSystemFont,Segoe UI,Arial,sans-serif';
    ctx.fillText('Reference', 80, y + 30);
    ctx.fillStyle = '#2f3a45';
    ctx.font = '500 24px -apple-system,BlinkMacSystemFont,Segoe UI,Arial,sans-serif';
    wrapCanvasText(ctx, apa(data) || gbt(data) || data.title, 80, y + 78, 1040, 36, 10);
    const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/jpeg', 0.92));
    const jpeg = new Uint8Array(await blob.arrayBuffer());
    return pdfWithJpeg(jpeg, canvas.width, canvas.height);
  }

  async function copy(text) {
    try {
      await navigator.clipboard.writeText(text);
    } catch (_) {
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
    }
  }

  function button(label) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = label;
    btn.style.cssText = 'width:auto!important;min-width:0!important;border:1px solid #d8cbb9;background:#fffdf8;border-radius:4px;padding:1px 6px;color:#6b3f18;font-weight:700;cursor:pointer;font-size:12px;line-height:1.45;';
    return btn;
  }

  function select(options) {
    const sel = document.createElement('select');
    sel.style.cssText = 'width:auto!important;min-width:54px!important;max-width:96px!important;height:auto!important;border:1px solid #d8cbb9;background:#fff;border-radius:4px;padding:1px 20px 1px 6px;color:#4b4032;font-weight:700;font-size:12px;line-height:1.45;';
    options.forEach(([value, label]) => {
      const opt = document.createElement('option');
      opt.value = value;
      opt.textContent = label;
      sel.appendChild(opt);
    });
    return sel;
  }

  function formatPayload(data, fmt) {
    if (fmt === 'ris') return { filename: `${citationKey(data)}.ris`, text: ris(data), mode: 'download' };
    if (fmt === 'bib') return { filename: `${citationKey(data)}.bib`, text: bibtex(data), mode: 'download' };
    if (fmt === 'enw') return { filename: `${citationKey(data)}.enw`, text: enw(data), mode: 'download' };
    if (fmt === 'apa') return { text: apa(data), mode: 'copy' };
    if (fmt === 'ama') return { text: numbered(data), mode: 'copy' };
    if (fmt === 'acs') return { text: numbered(data), mode: 'copy' };
    if (fmt === 'gbt') return { text: gbt(data), mode: 'copy' };
    return null;
  }

  function renderTools(extra = {}) {
    const data = fromDocument(extra);
    if (!data.title && !data.doi) return null;
    const bar = document.createElement('div');
    bar.className = 'ailatest-citation-tools';
    bar.dataset.ailatestUi = '1';
    bar.style.cssText = 'display:inline-flex;flex-wrap:wrap;align-items:center;gap:4px;margin:0 0 0 4px;font:12px -apple-system,BlinkMacSystemFont,Segoe UI,Arial,sans-serif;vertical-align:middle;';
    const fmt = select([
      ['ris', 'RIS'],
      ['bib', 'BibTeX'],
      ['enw', 'EndNote'],
      ['apa', 'APA'],
      ['ama', 'AMA'],
      ['acs', 'ACS'],
      ['gbt', 'GB/T 7714'],
    ]);
    const exportBtn = button(ns.t ? ns.t('citation.export') : 'Export');
    exportBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      const payload = formatPayload(data, fmt.value);
      if (!payload) return;
      if (payload.mode === 'download') download(payload.filename, payload.text);
      else {
        await copy(payload.text);
        exportBtn.textContent = ns.t ? ns.t('citation.copied') : 'Copied';
        setTimeout(() => { exportBtn.textContent = ns.t ? ns.t('citation.export') : 'Export'; }, 1200);
      }
    });
    const saveBtn = button(ns.t ? ns.t('citation.saveMd') : 'Save MD');
    saveBtn.title = ns.t ? ns.t('citation.saveMdTitle') : 'Download a Markdown citation card and save it in the local library';
    saveBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      await saveCitation(data, 'md');
      download(`${citationKey(data)}.md`, citationMarkdown(data), 'text/markdown;charset=utf-8');
      saveBtn.textContent = ns.t ? ns.t('citation.saved') : 'Saved';
      setTimeout(() => { saveBtn.textContent = ns.t ? ns.t('citation.saveMd') : 'Save MD'; }, 1200);
    });
    const pdfBtn = button('PDF');
    pdfBtn.title = ns.t ? ns.t('citation.savePdfTitle') : 'Download a PDF citation card';
    pdfBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      pdfBtn.textContent = '...';
      await saveCitation(data, 'pdf');
      downloadBlob(`${citationKey(data)}.pdf`, await citationPdf(data));
      pdfBtn.textContent = ns.t ? ns.t('citation.saved') : 'Saved';
      setTimeout(() => { pdfBtn.textContent = 'PDF'; }, 1200);
    });
    bar.append(fmt, exportBtn, saveBtn, pdfBtn);
    return bar;
  }

  async function citationCounts(data) {
    const out = [];
    const doi = clean(data && data.doi);
    if (!doi) return out;
    try {
      const oa = await fetch(`https://api.openalex.org/works/doi:${encodeURIComponent(doi)}`).then(r => r.ok ? r.json() : null);
      if (oa && oa.cited_by_count != null) out.push({ source: 'OpenAlex', count: oa.cited_by_count });
    } catch (_) {}
    try {
      const ss = await fetch(`https://api.semanticscholar.org/graph/v1/paper/DOI:${encodeURIComponent(doi)}?fields=citationCount`).then(r => r.ok ? r.json() : null);
      if (ss && ss.citationCount != null) out.push({ source: 'Semantic Scholar', count: ss.citationCount });
    } catch (_) {}
    try {
      const cr = await fetch(`https://api.crossref.org/works/${encodeURIComponent(doi)}`).then(r => r.ok ? r.json() : null);
      const n = cr && cr.message && cr.message['is-referenced-by-count'];
      if (n != null) out.push({ source: 'Crossref', count: n });
    } catch (_) {}
    return out;
  }

  async function renderCitationCounts(extra = {}) {
    const data = fromDocument(extra);
    const counts = await citationCounts(data);
    if (!counts.length) return null;
    const box = document.createElement('div');
    box.className = 'ailatest-citation-counts';
    box.dataset.ailatestUi = '1';
    box.style.cssText = 'display:inline-flex;position:relative;margin:4px 0 8px;font:12px -apple-system,BlinkMacSystemFont,Segoe UI,Arial,sans-serif;color:#46546a;';
    const total = Math.max(...counts.map((x) => Number(x.count) || 0));
    const btn = button(ns.t ? ns.t('citation.count', { count: total }) : `Citations ${total}`);
    btn.style.borderColor = '#d8dee8';
    btn.style.background = '#f8fafc';
    btn.style.color = '#46546a';
    const detail = document.createElement('div');
    detail.hidden = true;
    detail.style.cssText = 'position:absolute;z-index:2147483647;top:26px;left:0;min-width:180px;background:#fff;border:1px solid #d8dee8;border-radius:6px;box-shadow:0 8px 24px rgba(15,23,42,.12);padding:6px;color:#334155;';
    detail.innerHTML = counts.map((item) => `<div style="display:flex;justify-content:space-between;gap:18px;padding:3px 4px"><b>${item.source}</b><span>${item.count}</span></div>`).join('');
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      detail.hidden = !detail.hidden;
    });
    box.append(btn, detail);
    return box;
  }

  async function resolveOpenAccessUrl(data) {
    if (data.pdfUrl) return data.pdfUrl;
    if (data.doi) {
      try {
        const oa = await fetch(`https://api.openalex.org/works/doi:${encodeURIComponent(data.doi)}`).then(r => r.ok ? r.json() : null);
        const locs = [oa && oa.best_oa_location, ...(Array.isArray(oa && oa.oa_locations) ? oa.oa_locations : [])].filter(Boolean);
        const hit = locs.find((x) => x && (x.pdf_url || x.landing_page_url));
        if (hit) return hit.pdf_url || hit.landing_page_url;
      } catch (_) {}
    }
    return '';
  }

  function sourceCandidates(data) {
    const doi = clean(data.doi);
    const title = clean(data.title);
    return [
      ['OpenAlex', doi ? `https://openalex.org/doi/${encodeURIComponent(doi)}` : `https://openalex.org/works?search=${encodeURIComponent(title)}`],
      ['Unpaywall', doi ? `https://unpaywall.org/doi/${encodeURIComponent(doi)}` : ''],
      ['Semantic Scholar', doi ? `https://www.semanticscholar.org/search?q=${encodeURIComponent(doi)}` : `https://www.semanticscholar.org/search?q=${encodeURIComponent(title)}`],
      ['Crossref', doi ? `https://search.crossref.org/?q=${encodeURIComponent(doi)}` : `https://search.crossref.org/?q=${encodeURIComponent(title)}`],
      ['CORE', title ? `https://core.ac.uk/search?q=${encodeURIComponent(title)}` : ''],
      ['PubMed', doi ? `https://pubmed.ncbi.nlm.nih.gov/?term=${encodeURIComponent(doi)}` : `https://pubmed.ncbi.nlm.nih.gov/?term=${encodeURIComponent(title)}`],
      ['ResearchGate', title ? `https://www.researchgate.net/search/publication?q=${encodeURIComponent(title)}` : ''],
    ].filter(([, url]) => url);
  }

  function renderSourceLinks(extra = {}) {
    const data = fromDocument(extra);
    const links = sourceCandidates(data);
    if (!links.length && !data.pdfUrl) return null;
    const bar = document.createElement('div');
    bar.className = 'ailatest-source-links';
    bar.dataset.ailatestUi = '1';
    bar.style.cssText = 'display:inline-flex;position:relative;align-items:center;gap:4px;margin:0 0 0 4px;font:12px -apple-system,BlinkMacSystemFont,Segoe UI,Arial,sans-serif;vertical-align:middle;';
    const openBtn = button(ns.t ? ns.t('source.fulltext') : 'Full text');
    const menuBtn = button(ns.t ? ns.t('source.sources') : 'Sources');
    const menu = document.createElement('div');
    menu.hidden = true;
    menu.style.cssText = 'position:absolute;z-index:2147483647;top:28px;left:58px;min-width:180px;background:#fff;border:1px solid #d8cbb9;border-radius:6px;box-shadow:0 8px 24px rgba(15,23,42,.12);padding:6px;';
    links.forEach(([label, url]) => {
      const a = document.createElement('a');
      a.href = url;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      a.textContent = label;
      a.style.cssText = 'display:block;padding:4px 6px;color:#6b3f18;font-weight:700;text-decoration:none;border-radius:4px;';
      a.addEventListener('mouseenter', () => { a.style.background = '#fff7ed'; });
      a.addEventListener('mouseleave', () => { a.style.background = 'transparent'; });
      menu.appendChild(a);
    });
    openBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      e.stopPropagation();
      const old = openBtn.textContent;
      openBtn.textContent = ns.t ? ns.t('source.finding') : 'Finding';
      const url = await resolveOpenAccessUrl(data);
      openBtn.textContent = old;
      if (url) window.open(url, '_blank', 'noopener');
      else menu.hidden = false;
    });
    menuBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      menu.hidden = !menu.hidden;
    });
    bar.append(openBtn, menuBtn, menu);
    return bar;
  }

  ns.citations = { fromDocument, renderTools, renderSourceLinks, renderCitationCounts, citationCounts, formats: { ris, enw, bibtex, apa, ama: numbered, acs: numbered, gbt, markdown: citationMarkdown } };
})(globalThis);
