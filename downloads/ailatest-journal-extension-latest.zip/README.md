# AILatest Journal Badges Extension (v0.2.18)

MV3 browser extension for showing AILatest journal badges on academic pages.

## Load Locally

1. Open Chrome or Edge extension management.
2. Enable developer mode.
3. Click "Load unpacked".
4. Select this `extension/` folder.

## Current Site Adapters

- CNKI: `*.cnki.net`
- Google Scholar: `scholar.google.com` and several common Google Scholar domains
- PubMed: `pubmed.ncbi.nlm.nih.gov`
- Taylor & Francis: `*.tandfonline.com`
- Article metadata pages: Springer, IEEE Xplore, ScienceDirect, MDPI, Wiley, Web of Science, Scopus, Europe PMC, Semantic Scholar, arXiv, and other listed hosts in `manifest.json`

The extension only injects on the hosts listed in `manifest.json`. It does not attempt to alter arbitrary publisher homepages, so an unsupported page will remain unchanged instead of receiving a misleading badge.

The content script scans journal names or ISSNs, batches lookups through:

```text
https://journal.ailatest.org/api/ext/lookup
```

Results are cached in `chrome.storage.local` for 7 days. Badge display settings are stored in `chrome.storage.sync`.
Article pages expose one lightweight citation action: **Copy reference**. It copies a plain-text APA-style reference (GB/T 7714 fallback) and does not create PDF/Markdown downloads.

## Add A Site Adapter

1. Add `src/adapters/<site>.js`.
2. Push an adapter into `AILatestExt.adapters`:

```js
AILatestExt.adapters.push({
  id: 'site-id',
  match: (host) => /example\.com$/.test(host),
  findEntries: () => [{ anchorEl, issn, journalName }],
  insert: (anchorEl, badgeNode) => anchorEl.insertAdjacentElement('afterend', badgeNode)
});
```

3. Add the adapter file and site match pattern to `manifest.json`.

Prefer ISSN when the page exposes it. Fall back to a clean journal name only when the source text is clearly a journal title.
